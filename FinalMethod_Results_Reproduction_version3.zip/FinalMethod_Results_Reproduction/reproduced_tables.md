# Reproduced tables (from CSVs)

## Normal-scenario metrics (per topology)

| Topology   |    N |   MeanPR |   MedPR | PR>=.95   | PR>=.90   |   MinPR |   MeanDB |   P95DB |   MaxDB |   Mean_ms |   P95_ms |
|:-----------|-----:|---------:|--------:|:----------|:----------|--------:|---------:|--------:|--------:|----------:|---------:|
| Abilene    | 2016 |   0.9843 |  1      | 87%       | 97%       |  0.8109 |   0.0058 |  0.0202 |  0.051  |      10.7 |     20.4 |
| GEANT      |  672 |   0.9983 |  0.9999 | 99%       | 99%       |  0.5848 |   0.003  |  0.0057 |  0.0701 |      66.6 |    121.1 |
| CERNET     |  200 |   0.9925 |  1      | 96%       | 100%      |  0.8933 |   0.0002 |  0.0008 |  0.0077 |      46.1 |    120.7 |
| Sprintlink |  200 |   0.996  |  1      | 100%      | 100%      |  0.96   |   0.0034 |  0.009  |  0.0546 |     174.8 |    278.8 |
| Tiscali    |  200 |   0.9522 |  0.9543 | 54%       | 100%      |  0.8928 |   0.002  |  0.0092 |  0.0311 |      76.8 |    298.4 |
| Ebone      |  200 |   0.9713 |  0.9806 | 82%       | 96%       |  0.8874 |   0.0003 |  0.0016 |  0.0133 |       3   |     33.6 |
| Germany50  |  288 |   0.9878 |  0.9989 | 96%       | 97%       |  0.409  |   0.0098 |  0.0406 |  0.0659 |     212.6 |    285.5 |
| VtlWavenet |   40 |   0.9373 |  0.9383 | 0%        | 100%      |  0.931  |   0.0007 |  0.0014 |  0.0017 |     295.9 |    307.3 |

## MLU and MLU/optimum (=1/PR)

| Topology   |   MeanMLU |   P95MLU |   MaxMLU |   MeanMLU/opt |
|:-----------|----------:|---------:|---------:|--------------:|
| Abilene    |    0.0506 |   0.0668 |   0.1132 |        1.0171 |
| GEANT      |    0.1091 |   0.1313 |   0.194  |        1.0025 |
| CERNET     |    0.6338 |   0.865  |   0.8975 |        1.0079 |
| Sprintlink |    0.7134 |   0.8772 |   0.9029 |        1.0041 |
| Tiscali    |    0.6457 |   0.869  |   0.8976 |        1.0508 |
| Ebone      |    0.7291 |   0.8767 |   0.9584 |        1.0304 |
| Germany50  |   12.4247 |  16.3146 |  26.1577 |        1.0181 |
| VtlWavenet |    1.0391 |   1.097  |   1.0987 |        1.0669 |

## Pooled summary (all cycles)

| Metric   | Value   |
|:---------|:--------|
| Cycles   | 3816    |
| MeanPR   | 0.9852  |
| MedianPR | 0.9999  |
| PR>=0.95 | 88.2%   |
| PR>=0.90 | 97.7%   |
| MinPR    | 0.409   |
| MeanDB   | 0.0047  |
| P95DB    | 0.0167  |
| Mean_ms  | 52.3    |
| P95_ms   | 221.7   |
| Max_ms   | 477.2   |

## Action distribution (per topology)

| Topology       |   KEEP |   K50 |   K100 |   K200 |   K300 |   K500 |   K800 | Most_used   |
|:---------------|-------:|------:|-------:|-------:|-------:|-------:|-------:|:------------|
| abilene        |    607 |   983 |      0 |      0 |      4 |     51 |    371 | K50         |
| geant          |      0 |     5 |      0 |    664 |      0 |      1 |      2 | K200        |
| cernet         |     92 |    63 |      3 |      6 |     36 |      0 |      0 | KEEP        |
| sprintlink     |     36 |     0 |      0 |      0 |      4 |     20 |    140 | K800        |
| tiscali        |    136 |     0 |      0 |      0 |      1 |     16 |     47 | KEEP        |
| ebone          |    185 |    15 |      0 |      0 |      0 |      0 |      0 | KEEP        |
| germany50      |      0 |     0 |      0 |      0 |      0 |      0 |    288 | K800        |
| vtlwavenet2011 |      1 |    39 |      0 |      0 |      0 |      0 |      0 | K50         |

## FlexDATE comparison (learned)  ->  3/4 wins (Abilene, CERNET, GEANT); Sprintlink 0.9960<0.999; Tiscali not scored

| Topology   | TargetPR   |   OurPR | TargetDB   |   OurDB | FlexDATE   |
|:-----------|:-----------|--------:|:-----------|--------:|:-----------|
| Abilene    | 0.958      |  0.9843 | 0.0513     |  0.0058 | WIN        |
| CERNET     | 0.975      |  0.9925 | 0.0183     |  0.0002 | WIN        |
| GEANT      | 0.995      |  0.9983 | 0.0296     |  0.003  | WIN        |
| Sprintlink | 0.999      |  0.996  | 0.051      |  0.0034 | no         |
| Tiscali    | no ref     |  0.9522 | no ref     |  0.002  | not scored |

## Zero-shot generalization (incl. VtlWavenet 40 vs 200 TMs)

| Zero-shot                    |   N |   MeanPR | PR>=.90   |   MinPR |   Mean_ms |
|:-----------------------------|----:|---------:|:----------|--------:|----------:|
| Germany50                    | 288 |   0.9878 | 97%       |  0.409  |     212.6 |
| VtlWavenet (40 TMs)          |  40 |   0.9373 | 100%      |  0.931  |     295.9 |
| VtlWavenet (200 TMs, robust) | 200 |   0.934  | 100%      |  0.9251 |     326.2 |

## Decision time by action type (pooled)

| Action   |   Rows |   Mean_ms |   P95_ms |   Max_ms |
|:---------|-------:|----------:|---------:|---------:|
| KEEP     |   1057 |       0.5 |      0.5 |      0.5 |
| K50      |   1105 |      25.7 |     57.7 |    477.2 |
| K100     |      3 |      70.3 |     71   |     71   |
| K200     |    670 |      67.1 |    121.2 |    199.2 |
| K300     |     45 |     126   |    220.6 |    259.1 |
| K500     |     88 |      79.4 |    195.9 |    239.7 |
| K800     |    848 |     132.9 |    278.2 |    387.4 |

## Worst-case hardening Tier B (clears FlexDATE worst-case on all 4, <500ms)

| topology   |   flexdate_worst |   min_pr_frozen |   min_pr_hardened | k_floor   |   mean_pr |   mean_ms |   p95_ms |   mean_db | cleared   |
|:-----------|-----------------:|----------------:|------------------:|:----------|----------:|----------:|---------:|----------:|:----------|
| abilene    |            0.87  |          0.781  |            0.9656 | K300      |    1      |      23   |     24.7 |    0.007  | True      |
| geant      |            0.87  |          0.991  |            0.9998 | K300      |    1      |      93.9 |    145.6 |    0.0024 | True      |
| sprintlink |            0.976 |          0.96   |            0.9768 | K300      |    0.9965 |     206   |    271.7 |    0.0045 | True      |
| tiscali    |            0.932 |          0.8928 |            0.9349 | K800      |    0.9754 |     284.5 |    365.2 |    0.0036 | True      |

## Disconnected-OD root cause (Case A physical partition vs Case B candidate-path limitation)

| topology       | scenario              |   od_index | src    | dst    |   num_candidate_paths_before | nx_path_exists_after_failure   | case                          | graph_strongly_connected   | failed_links                                   |
|:---------------|:----------------------|-----------:|:-------|:-------|-----------------------------:|:-------------------------------|:------------------------------|:---------------------------|:-----------------------------------------------|
| abilene        | three_link_failure    |         54 | HSTNng | WASHng |                            2 | True                           | B (candidate-path limitation) | True                       | HSTNng->ATLAng; NYCMng->WASHng; SNVAng->STTLng |
| abilene        | three_link_failure    |         87 | LOSAng | WASHng |                            2 | True                           | B (candidate-path limitation) | True                       | HSTNng->ATLAng; NYCMng->WASHng; SNVAng->STTLng |
| abilene        | three_link_failure    |        109 | SNVAng | WASHng |                            6 | True                           | B (candidate-path limitation) | True                       | HSTNng->ATLAng; NYCMng->WASHng; SNVAng->STTLng |
| vtlwavenet2011 | single_link_failure   |         89 | n000   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |
| vtlwavenet2011 | single_link_failure   |       8370 | n091   | n089   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |
| vtlwavenet2011 | single_link_failure   |       8371 | n091   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |
| vtlwavenet2011 | two_link_failure      |         89 | n000   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | two_link_failure      |       8189 | n089   | n091   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | two_link_failure      |       8190 | n090   | n000   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | two_link_failure      |       8280 | n090   | n091   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | two_link_failure      |       8370 | n091   | n089   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | two_link_failure      |       8371 | n091   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n090->n091; n091->n090                         |
| vtlwavenet2011 | three_link_failure    |         89 | n000   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       2816 | n030   | n087   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       2817 | n030   | n088   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       2818 | n030   | n089   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       2819 | n030   | n090   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       7946 | n087   | n029   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8037 | n088   | n029   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8128 | n089   | n029   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8189 | n089   | n091   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8190 | n090   | n000   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8219 | n090   | n029   |                            2 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8280 | n090   | n091   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8370 | n091   | n089   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | three_link_failure    |       8371 | n091   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n030->n029; n090->n091; n091->n090             |
| vtlwavenet2011 | random_link_failure_1 |       2389 | n026   | n023   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | random_link_failure_1 |       2390 | n026   | n024   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | random_link_failure_1 |       2391 | n026   | n025   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | random_link_failure_1 |       2481 | n027   | n024   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | random_link_failure_1 |       2482 | n027   | n025   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | random_link_failure_1 |       2573 | n028   | n025   |                            1 | True                           | B (candidate-path limitation) | True                       | n026->n025                                     |
| vtlwavenet2011 | mixed_spike_failure   |         89 | n000   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |
| vtlwavenet2011 | mixed_spike_failure   |       8370 | n091   | n089   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |
| vtlwavenet2011 | mixed_spike_failure   |       8371 | n091   | n090   |                            1 | True                           | B (candidate-path limitation) | True                       | n091->n090                                     |

## VtlWavenet coverage scalability (K-sweep: coverage vs PR vs runtime)

|   K_budget |   ODs_optimized |   coverage_pct |   mean_PR |   min_PR |   MLU_vs_ECMP_pct |   reduction_pct |   mean_ms |   p95_ms | under_500   |
|-----------:|----------------:|---------------:|----------:|---------:|------------------:|----------------:|----------:|---------:|:------------|
|         50 |              50 |           0.6  |    0.9373 |   0.931  |              98   |             2   |     302.7 |    307.7 | True        |
|        200 |             200 |           2.39 |    0.9422 |   0.9366 |              97.5 |             2.5 |     351.1 |    364.1 | True        |
|        500 |             500 |           5.97 |    0.9527 |   0.9449 |              96.4 |             3.6 |     418.7 |    488.8 | True        |
|        800 |             800 |           9.56 |    0.9603 |   0.9501 |              95.7 |             4.3 |     523.1 |    593.1 | False       |
|       1200 |            1200 |          14.33 |    0.971  |   0.9586 |              94.6 |             5.4 |     662.2 |    749.7 | False       |
|       2000 |            2000 |          23.89 |    0.984  |   0.9692 |              93.4 |             6.6 |     979.8 |   1040.2 | False       |

## Ranking ablation (gnn-only vs relief-only vs blend)

| topology   |   K | ranking     |   mean_PR |   mean_ms |
|:-----------|----:|:------------|----------:|----------:|
| sprintlink | 500 | gnn_only    |    0.97   |     256.9 |
| sprintlink | 500 | relief_only |    0.9979 |     259.3 |
| sprintlink | 500 | blend       |    0.996  |     251.6 |
| sprintlink | 800 | gnn_only    |    0.9883 |     374.5 |
| sprintlink | 800 | relief_only |    1      |     380.1 |
| sprintlink | 800 | blend       |    0.9993 |     377.9 |
| tiscali    | 300 | gnn_only    |    0.9268 |     206.4 |
| tiscali    | 300 | relief_only |    0.9236 |     193.5 |
| tiscali    | 300 | blend       |    0.9243 |     207.8 |
| germany50  | 200 | gnn_only    |    0.9356 |     127.6 |
| germany50  | 200 | relief_only |    0.99   |     141.1 |
| germany50  | 200 | blend       |    0.9555 |     131.1 |
| cernet     |  50 | gnn_only    |    1      |      55.1 |
| cernet     |  50 | relief_only |    1      |      54.5 |
| cernet     |  50 | blend       |    1      |      61   |

## Failure scenarios (ALL 8 topologies, 9 scenarios x 20 cycles = 72 runs)

| Topology       | Scenario                |   N |   Mean_MLU |    P95_MLU |   Peak_MLU |   Mean_PR |   Mean_DB |   P95_DB |   Mean_ms |   ECMP_Mean_MLU |   Disconnected_ODs |
|:---------------|:------------------------|----:|-----------:|-----------:|-----------:|----------:|----------:|---------:|----------:|----------------:|-------------------:|
| abilene        | normal                  |  20 |     0.0612 |     0.1127 |     0.1132 |    0.9921 |    0.0303 |   0.0967 |      14.5 |          0.1599 |                  0 |
| abilene        | single_link_failure     |  20 |     0.0652 |     0.118  |     0.1448 |    0.9926 |    0.0363 |   0.0974 |      14.5 |          0.1603 |                  0 |
| abilene        | two_link_failure        |  20 |     0.079  |     0.1282 |     0.1584 |    0.8965 |    0.0326 |   0.1001 |      13.4 |          0.1669 |                  0 |
| abilene        | three_link_failure      |  20 |     0.121  |     0.173  |     0.2117 |    1      |    0.001  |   0.001  |      12.2 |          0.1377 |                  3 |
| abilene        | random_link_failure_1   |  20 |     0.0705 |     0.1246 |     0.1543 |    0.9854 |    0.0391 |   0.1    |      15.1 |          0.1638 |                  0 |
| abilene        | random_link_failure_2   |  20 |     0.1179 |     0.1708 |     0.208  |    0.9191 |    0.0089 |   0.0296 |      13.4 |          0.2488 |                  0 |
| abilene        | spike                   |  20 |     0.1808 |     0.2874 |     0.3395 |    1      |    0.0189 |   0.0919 |      18.5 |          0.4796 |                  0 |
| abilene        | mixed_spike_failure     |  20 |     0.1938 |     0.341  |     0.4344 |    0.9998 |    0.0298 |   0.0973 |      18.4 |          0.4809 |                  0 |
| abilene        | capacity_degradation_50 |  20 |     0.1224 |     0.2264 |     0.2268 |    0.9918 |    0.0229 |   0.0901 |      14.8 |          0.3198 |                  0 |
| geant          | normal                  |  20 |     0.121  |     0.1267 |     0.1369 |    0.9912 |    0.0115 |   0.0675 |      68.2 |          0.2901 |                  0 |
| geant          | single_link_failure     |  20 |     0.1808 |     0.1894 |     0.1938 |    0.9938 |    0.0088 |   0.0305 |      65.9 |          0.3564 |                  0 |
| geant          | two_link_failure        |  20 |     0.1808 |     0.1893 |     0.1922 |    0.9942 |    0.0084 |   0.0213 |      81.5 |          0.3561 |                  0 |
| geant          | three_link_failure      |  20 |     0.1807 |     0.1893 |     0.1913 |    0.9944 |    0.0078 |   0.0187 |      76.7 |          0.3565 |                  0 |
| geant          | random_link_failure_1   |  20 |     0.1211 |     0.1268 |     0.1389 |    0.9906 |    0.0117 |   0.0603 |      75.8 |          0.2901 |                  0 |
| geant          | random_link_failure_2   |  20 |     0.1212 |     0.1269 |     0.1409 |    0.99   |    0.012  |   0.0739 |      66.8 |          0.2945 |                  0 |
| geant          | spike                   |  20 |     0.363  |     0.38   |     0.4138 |    0.9911 |    0.0117 |   0.0687 |      90.1 |          0.8704 |                  0 |
| geant          | mixed_spike_failure     |  20 |     0.5425 |     0.5681 |     0.5815 |    0.9939 |    0.009  |   0.0307 |      83.5 |          1.0693 |                  0 |
| geant          | capacity_degradation_50 |  20 |     0.2421 |     0.2535 |     0.2758 |    0.9908 |    0.0157 |   0.0694 |      73.3 |          0.5802 |                  0 |
| cernet         | normal                  |  20 |  1784.31   |  1812.4    |  1856.02   |    0.9834 |    0.0088 |   0.0283 |     211.5 |       2824.09   |                  0 |
| cernet         | single_link_failure     |  20 |  1785.07   |  1813.03   |  1868.74   |    0.983  |    0.0093 |   0.0345 |     199.2 |       2824.09   |                  0 |
| cernet         | two_link_failure        |  20 |  1785.07   |  1813.03   |  1868.74   |    0.983  |    0.0091 |   0.0356 |     193.2 |       2824.09   |                  0 |
| cernet         | three_link_failure      |  20 |  2518.33   |  2577.53   |  2595.83   |    1      |    0.0032 |   0.0056 |     192.8 |       2946.82   |                  1 |
| cernet         | random_link_failure_1   |  20 |  1805.65   |  1834.94   |  1928.12   |    0.9719 |    0.0093 |   0.0371 |     185.1 |       2653.61   |                  0 |
| cernet         | random_link_failure_2   |  20 |  1785.85   |  1813.24   |  1872.86   |    0.9826 |    0.009  |   0.0316 |     202.3 |       2824.09   |                  0 |
| cernet         | spike                   |  20 |  5337.36   |  5429.23   |  5564.85   |    0.9862 |    0.0093 |   0.0326 |     201.5 |       8472.26   |                  0 |
| cernet         | mixed_spike_failure     |  20 |  5339.27   |  5431.14   |  5603.02   |    0.9859 |    0.0094 |   0.0364 |     197.8 |       8472.26   |                  0 |
| cernet         | capacity_degradation_50 |  20 |  3561.57   |  3619.49   |  3709.9    |    0.9853 |    0.009  |   0.0315 |     190.8 |       5648.17   |                  0 |
| sprintlink     | normal                  |  20 |   923.699  |   946.052  |   947.021  |    0.9956 |    0.0057 |   0.0071 |     204.1 |       1499.77   |                  0 |
| sprintlink     | single_link_failure     |  20 |   924.385  |   948.757  |   953.279  |    0.9948 |    0.0055 |   0.0071 |     195.2 |       1499.77   |                  0 |
| sprintlink     | two_link_failure        |  20 |   923.03   |   946.104  |   947.021  |    0.9963 |    0.0049 |   0.0068 |     203.2 |       1403.67   |                  0 |
| sprintlink     | three_link_failure      |  20 |   924.53   |   946.417  |   953.279  |    0.9947 |    0.0053 |   0.007  |     206.2 |       1403.67   |                  0 |
| sprintlink     | random_link_failure_1   |  20 |   924.073  |   946.052  |   947.021  |    0.9951 |    0.0054 |   0.0068 |     200   |       1495.36   |                  0 |
| sprintlink     | random_link_failure_2   |  20 |   924.981  |   948.757  |   953.279  |    0.9942 |    0.0056 |   0.0071 |     202.1 |       1502.72   |                  0 |
| sprintlink     | spike                   |  20 |  2761.46   |  2823.51   |  2828.15   |    0.999  |    0.0054 |   0.0066 |     205.1 |       4499.32   |                  0 |
| sprintlink     | mixed_spike_failure     |  20 |  2761.8    |  2823.51   |  2828.15   |    0.9989 |    0.0053 |   0.0061 |     212   |       4499.32   |                  0 |
| sprintlink     | capacity_degradation_50 |  20 |  1841.2    |  1882.34   |  1885.43   |    0.9989 |    0.0055 |   0.0066 |     211   |       2999.55   |                  0 |
| tiscali        | normal                  |  20 |   982.799  |   998.265  |   998.445  |    0.936  |    0.0128 |   0.0246 |     305   |       1365.82   |                  0 |
| tiscali        | single_link_failure     |  20 |   983.639  |   998.265  |   998.445  |    0.9353 |    0.0141 |   0.0332 |     310.5 |       1404.58   |                  0 |
| tiscali        | two_link_failure        |  20 |   978.846  |   995.138  |   995.535  |    0.9399 |    0.016  |   0.0458 |     328.1 |       1356.58   |                  0 |
| tiscali        | three_link_failure      |  20 |  1033.67   |  1055.08   |  1057.01   |    0.9697 |    0.0126 |   0.0195 |     376.9 |       1591.4    |                  0 |
| tiscali        | random_link_failure_1   |  20 |   978.33   |   995.138  |   995.535  |    0.9402 |    0.0147 |   0.0359 |     317.4 |       1324.91   |                  0 |
| tiscali        | random_link_failure_2   |  20 |   982.604  |   998.532  |  1000.2    |    0.9361 |    0.0147 |   0.0357 |     314.4 |       1446.12   |                  0 |
| tiscali        | spike                   |  20 |  2950.65   |  2999.53   |  3010.18   |    0.9352 |    0.013  |   0.026  |     284.8 |       4097.45   |                  0 |
| tiscali        | mixed_spike_failure     |  20 |  2954.71   |  2999.53   |  3010.18   |    0.9341 |    0.0141 |   0.0351 |     301.2 |       4213.74   |                  0 |
| tiscali        | capacity_degradation_50 |  20 |  1967.1    |  1999.69   |  2006.79   |    0.9352 |    0.013  |   0.0265 |     294.8 |       2731.63   |                  0 |
| ebone          | normal                  |  20 |   532.261  |   540.418  |   542.538  |    1      |    0.0027 |   0.0049 |     106.5 |        602.974  |                  0 |
| ebone          | single_link_failure     |  20 |   569.547  |   594.139  |   602.219  |    1      |    0.0016 |   0.0062 |     104.4 |        611.578  |                  0 |
| ebone          | two_link_failure        |  20 |   569.547  |   594.139  |   602.219  |    1      |    0.0018 |   0.0076 |      99.6 |        627.549  |                  0 |
| ebone          | three_link_failure      |  20 |   569.547  |   594.139  |   602.219  |    1      |    0.0014 |   0.0055 |     100.7 |        626.843  |                  0 |
| ebone          | random_link_failure_1   |  20 |   532.261  |   540.418  |   542.538  |    1      |    0.0029 |   0.0061 |     106.8 |        620.358  |                  0 |
| ebone          | random_link_failure_2   |  20 |   532.261  |   540.418  |   542.538  |    1      |    0.0025 |   0.0051 |     108.1 |        642.337  |                  0 |
| ebone          | spike                   |  20 |  1596.78   |  1621.25   |  1627.61   |    1      |    0.0027 |   0.0049 |     105.7 |       1808.92   |                  0 |
| ebone          | mixed_spike_failure     |  20 |  1708.64   |  1782.42   |  1806.66   |    1      |    0.0016 |   0.0062 |     106.2 |       1834.73   |                  0 |
| ebone          | capacity_degradation_50 |  20 |  1064.52   |  1080.84   |  1085.08   |    1      |    0.0027 |   0.0049 |     105.4 |       1205.95   |                  0 |
| germany50      | normal                  |  20 |    10.3322 |    14.0238 |    21.5002 |    0.965  |    0.0256 |   0.1007 |     197.1 |         27.1542 |                  0 |
| germany50      | single_link_failure     |  20 |    10.2824 |    13.1115 |    21.4589 |    0.9681 |    0.0247 |   0.1007 |     201.2 |         27.1542 |                  0 |
| germany50      | two_link_failure        |  20 |    10.1082 |    12.1249 |    18.9342 |    0.9751 |    0.0252 |   0.1033 |     211   |         24.793  |                  0 |
| germany50      | three_link_failure      |  20 |    10.5195 |    12.0977 |    18.777  |    0.9799 |    0.0237 |   0.094  |     214.6 |         24.8144 |                  0 |
| germany50      | random_link_failure_1   |  20 |    10.2313 |    12.1462 |    21.4422 |    0.9719 |    0.0236 |   0.1007 |     189.7 |         27.1686 |                  0 |
| germany50      | random_link_failure_2   |  20 |     9.9541 |    11.4609 |    16.4726 |    0.982  |    0.0243 |   0.1007 |     196.8 |         22.9075 |                  0 |
| germany50      | spike                   |  20 |    30.7132 |    36.3883 |    64.4927 |    0.9715 |    0.0296 |   0.1063 |     199.6 |         81.4627 |                  0 |
| germany50      | mixed_spike_failure     |  20 |    30.7237 |    36.7288 |    64.3667 |    0.9711 |    0.0261 |   0.1045 |     195.5 |         81.4627 |                  0 |
| germany50      | capacity_degradation_50 |  20 |    20.5557 |    25.66   |    42.999  |    0.9683 |    0.0276 |   0.1063 |     184.6 |         54.3084 |                  0 |
| vtlwavenet2011 | normal                  |  20 | 17182.4    | 18170.2    | 18306      |    0.9543 |    0.0028 |   0.0043 |     513.5 |      18150.9    |                  0 |
| vtlwavenet2011 | single_link_failure     |  20 | 18589.4    | 19675.1    | 19898.3    |    0.9198 |    0.0064 |   0.0072 |     477.4 |      22109.7    |                  3 |
| vtlwavenet2011 | two_link_failure        |  20 | 18011.2    | 19024.3    | 19249.8    |    0.9493 |    0.0065 |   0.0092 |     477.4 |      21838.4    |                  6 |
| vtlwavenet2011 | three_link_failure      |  20 | 17925.6    | 18972.3    | 19147.5    |    0.9495 |    0.006  |   0.0104 |     458.3 |      21488.4    |                 14 |
| vtlwavenet2011 | random_link_failure_1   |  20 | 17195.6    | 18319.5    | 18473      |    0.9537 |    0.0108 |   0.0128 |     512.2 |      21490.2    |                  6 |
| vtlwavenet2011 | random_link_failure_2   |  20 | 17189.8    | 18202      | 18335.9    |    0.9539 |    0.0029 |   0.0038 |     505.6 |      18756.1    |                  0 |
| vtlwavenet2011 | spike                   |  20 | 51549.7    | 54510.6    | 54918.1    |    0.9543 |    0.0027 |   0.004  |     507.7 |      54452.8    |                  0 |
| vtlwavenet2011 | mixed_spike_failure     |  20 | 55786      | 59071.5    | 59727.9    |    0.9195 |    0.0062 |   0.0075 |     475.4 |      66329      |                  3 |
| vtlwavenet2011 | capacity_degradation_50 |  20 | 34366.4    | 36340.4    | 36612.1    |    0.9543 |    0.0028 |   0.004  |     497.7 |      36301.9    |                  0 |

## Failure: disconnected-OD detail (all 8 topologies)

| Topology       | Scenario                |   Failed_links | Connected   |   Disconnected_ODs | Explanation                                     |
|:---------------|:------------------------|---------------:|:------------|-------------------:|:------------------------------------------------|
| abilene        | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | three_link_failure      |              3 | partial     |                  3 | some ODs lost all candidate paths under failure |
| abilene        | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene        | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant          | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | three_link_failure      |              3 | partial     |                  1 | some ODs lost all candidate paths under failure |
| cernet         | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| cernet         | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| sprintlink     | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| tiscali        | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| ebone          | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| germany50      | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| vtlwavenet2011 | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| vtlwavenet2011 | single_link_failure     |              1 | partial     |                  3 | some ODs lost all candidate paths under failure |
| vtlwavenet2011 | two_link_failure        |              2 | partial     |                  6 | some ODs lost all candidate paths under failure |
| vtlwavenet2011 | three_link_failure      |              3 | partial     |                 14 | some ODs lost all candidate paths under failure |
| vtlwavenet2011 | random_link_failure_1   |              1 | partial     |                  6 | some ODs lost all candidate paths under failure |
| vtlwavenet2011 | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| vtlwavenet2011 | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| vtlwavenet2011 | mixed_spike_failure     |              1 | partial     |                  3 | some ODs lost all candidate paths under failure |
| vtlwavenet2011 | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |

## Proof of learning (trained vs untrained vs random vs fixed)

| policy    |   mean_reward |   mean_PR |   mean_ms |   action_entropy |
|:----------|--------------:|----------:|----------:|-----------------:|
| trained   |       17.8228 |  0.980565 |   66.1272 |      1.39383     |
| untrained |       17.073  |  0.986706 |  129.168  |      0.307941    |
| random    |       15.222  |  0.971916 |   99.7348 |      1.94453     |
| keep      |      -10.0477 |  0.687997 |    0.5    |     -1.00009e-12 |
| k800      |       17.6145 |  0.9933   |  177.999  |     -1.00009e-12 |

## Learning curve
TD loss 2.096->0.643; reward 15.16->18.03; td_updates=20620, ce_updates=0