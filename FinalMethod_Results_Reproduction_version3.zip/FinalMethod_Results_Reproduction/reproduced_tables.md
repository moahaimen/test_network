# Reproduced tables (from CSVs)

## Normal-scenario metrics (per topology)

| Topology   |    N |   MeanPR |   MedPR | PR>=.95   | PR>=.90   |   MinPR |   MeanDB |   P95DB |   MaxDB |   Mean_ms |   P95_ms |
|:-----------|-----:|---------:|--------:|:----------|:----------|--------:|---------:|--------:|--------:|----------:|---------:|
| Abilene    | 2016 |   0.9843 |  1      | 87%       | 97%       |  0.8109 |   0.0058 |  0.0202 |  0.051  |      10.7 |     20.4 |
| GEANT      |  672 |   0.9983 |  0.9999 | 99%       | 99%       |  0.5848 |   0.003  |  0.0057 |  0.0701 |      66.6 |    121.1 |
| CERNET     |  200 |   0.9925 |  1      | 96%       | 100%      |  0.8933 |   0.0002 |  0.0008 |  0.0077 |      46.1 |    120.7 |
| Sprintlink |  200 |   0.996  |  1      | 100%      | 100%      |  0.96   |   0.0034 |  0.009  |  0.0546 |     174.8 |    278.8 |
| Tiscali    |  200 |   0.9522 |  0.9543 | 54%       | 100%      |  0.8928 |   0.002  |  0.0092 |  0.0311 |      76.8 |    298.4 |
| Ebone      |  200 |   0.9713 |  0.9806 | 82%       | 96%       |  0.8874 |   0.0003 |  0.0016 |  0.0133 |       3   |     33.6 |
| Germany50  |  288 |   0.9878 |  0.9989 | 96%       | 97%       |  0.409  |   0.0098 |  0.0406 |  0.0659 |     212.6 |    285.5 |
| VtlWavenet |   40 |   0.9373 |  0.9383 | 0%        | 100%      |  0.931  |   0.0007 |  0.0014 |  0.0017 |     295.9 |    307.3 |

## MLU and MLU/optimum (=1/PR)

| Topology   |   MeanMLU |   P95MLU |   MaxMLU |   MeanMLU/opt |
|:-----------|----------:|---------:|---------:|--------------:|
| Abilene    |    0.0506 |   0.0668 |   0.1132 |        1.0171 |
| GEANT      |    0.1091 |   0.1313 |   0.194  |        1.0025 |
| CERNET     |    0.6338 |   0.865  |   0.8975 |        1.0079 |
| Sprintlink |    0.7134 |   0.8772 |   0.9029 |        1.0041 |
| Tiscali    |    0.6457 |   0.869  |   0.8976 |        1.0508 |
| Ebone      |    0.7291 |   0.8767 |   0.9584 |        1.0304 |
| Germany50  |   12.4247 |  16.3146 |  26.1577 |        1.0181 |
| VtlWavenet |    1.0391 |   1.097  |   1.0987 |        1.0669 |

## Pooled summary (all cycles)

| Metric   | Value   |
|:---------|:--------|
| Cycles   | 3816    |
| MeanPR   | 0.9852  |
| MedianPR | 0.9999  |
| PR>=0.95 | 88.2%   |
| PR>=0.90 | 97.7%   |
| MinPR    | 0.409   |
| MeanDB   | 0.0047  |
| P95DB    | 0.0167  |
| Mean_ms  | 52.3    |
| P95_ms   | 221.7   |
| Max_ms   | 477.2   |

## Action distribution (per topology)

| Topology       |   KEEP |   K50 |   K100 |   K200 |   K300 |   K500 |   K800 | Most_used   |
|:---------------|-------:|------:|-------:|-------:|-------:|-------:|-------:|:------------|
| abilene        |    607 |   983 |      0 |      0 |      4 |     51 |    371 | K50         |
| geant          |      0 |     5 |      0 |    664 |      0 |      1 |      2 | K200        |
| cernet         |     92 |    63 |      3 |      6 |     36 |      0 |      0 | KEEP        |
| sprintlink     |     36 |     0 |      0 |      0 |      4 |     20 |    140 | K800        |
| tiscali        |    136 |     0 |      0 |      0 |      1 |     16 |     47 | KEEP        |
| ebone          |    185 |    15 |      0 |      0 |      0 |      0 |      0 | KEEP        |
| germany50      |      0 |     0 |      0 |      0 |      0 |      0 |    288 | K800        |
| vtlwavenet2011 |      1 |    39 |      0 |      0 |      0 |      0 |      0 | K50         |

## FlexDATE comparison (learned)  ->  3/4 wins (Abilene, CERNET, GEANT); Sprintlink 0.9960<0.999; Tiscali not scored

| Topology   | TargetPR   |   OurPR | TargetDB   |   OurDB | FlexDATE   |
|:-----------|:-----------|--------:|:-----------|--------:|:-----------|
| Abilene    | 0.958      |  0.9843 | 0.0513     |  0.0058 | WIN        |
| CERNET     | 0.975      |  0.9925 | 0.0183     |  0.0002 | WIN        |
| GEANT      | 0.995      |  0.9983 | 0.0296     |  0.003  | WIN        |
| Sprintlink | 0.999      |  0.996  | 0.051      |  0.0034 | no         |
| Tiscali    | no ref     |  0.9522 | no ref     |  0.002  | not scored |

## Zero-shot generalization (incl. VtlWavenet 40 vs 200 TMs)

| Zero-shot                    |   N |   MeanPR | PR>=.90   |   MinPR |   Mean_ms |
|:-----------------------------|----:|---------:|:----------|--------:|----------:|
| Germany50                    | 288 |   0.9878 | 97%       |  0.409  |     212.6 |
| VtlWavenet (40 TMs)          |  40 |   0.9373 | 100%      |  0.931  |     295.9 |
| VtlWavenet (200 TMs, robust) | 200 |   0.934  | 100%      |  0.9251 |     326.2 |

## Decision time by action type (pooled)

| Action   |   Rows |   Mean_ms |   P95_ms |   Max_ms |
|:---------|-------:|----------:|---------:|---------:|
| KEEP     |   1057 |       0.5 |      0.5 |      0.5 |
| K50      |   1105 |      25.7 |     57.7 |    477.2 |
| K100     |      3 |      70.3 |     71   |     71   |
| K200     |    670 |      67.1 |    121.2 |    199.2 |
| K300     |     45 |     126   |    220.6 |    259.1 |
| K500     |     88 |      79.4 |    195.9 |    239.7 |
| K800     |    848 |     132.9 |    278.2 |    387.4 |

## Worst-case hardening Tier B (clears FlexDATE worst-case on all 4, <500ms)

| topology   |   flexdate_worst |   min_pr_frozen |   min_pr_hardened | k_floor   |   mean_pr |   mean_ms |   p95_ms |   mean_db | cleared   |
|:-----------|-----------------:|----------------:|------------------:|:----------|----------:|----------:|---------:|----------:|:----------|
| abilene    |            0.87  |          0.781  |            0.9656 | K300      |    1      |      23   |     24.7 |    0.007  | True      |
| geant      |            0.87  |          0.991  |            0.9998 | K300      |    1      |      93.9 |    145.6 |    0.0024 | True      |
| sprintlink |            0.976 |          0.96   |            0.9768 | K300      |    0.9965 |     206   |    271.7 |    0.0045 | True      |
| tiscali    |            0.932 |          0.8928 |            0.9349 | K800      |    0.9754 |     284.5 |    365.2 |    0.0036 | True      |

## Ranking ablation (gnn-only vs relief-only vs blend)

| topology   |   K | ranking     |   mean_PR |   mean_ms |
|:-----------|----:|:------------|----------:|----------:|
| sprintlink | 500 | gnn_only    |    0.97   |     256.9 |
| sprintlink | 500 | relief_only |    0.9979 |     259.3 |
| sprintlink | 500 | blend       |    0.996  |     251.6 |
| sprintlink | 800 | gnn_only    |    0.9883 |     374.5 |
| sprintlink | 800 | relief_only |    1      |     380.1 |
| sprintlink | 800 | blend       |    0.9993 |     377.9 |
| tiscali    | 300 | gnn_only    |    0.9268 |     206.4 |
| tiscali    | 300 | relief_only |    0.9236 |     193.5 |
| tiscali    | 300 | blend       |    0.9243 |     207.8 |
| germany50  | 200 | gnn_only    |    0.9356 |     127.6 |
| germany50  | 200 | relief_only |    0.99   |     141.1 |
| germany50  | 200 | blend       |    0.9555 |     131.1 |
| cernet     |  50 | gnn_only    |    1      |      55.1 |
| cernet     |  50 | relief_only |    1      |      54.5 |
| cernet     |  50 | blend       |    1      |      61   |

## Failure scenarios (Abilene + GEANT, 9 scenarios x 20 cycles)

| Topology   | Scenario                |   N |   Mean_MLU |   P95_MLU |   Peak_MLU |   Mean_PR |   Mean_DB |   P95_DB |   Mean_ms |   ECMP_Mean_MLU |   Disconnected_ODs |
|:-----------|:------------------------|----:|-----------:|----------:|-----------:|----------:|----------:|---------:|----------:|----------------:|-------------------:|
| abilene    | normal                  |  20 |     0.0612 |    0.1127 |     0.1132 |    0.9921 |    0.0303 |   0.0967 |      43.5 |          0.1599 |                  0 |
| abilene    | single_link_failure     |  20 |     0.0652 |    0.118  |     0.1448 |    0.9926 |    0.0363 |   0.0974 |      32.8 |          0.1603 |                  0 |
| abilene    | two_link_failure        |  20 |     0.079  |    0.1282 |     0.1584 |    0.8965 |    0.0326 |   0.1001 |      30.8 |          0.1669 |                  0 |
| abilene    | three_link_failure      |  20 |     0.121  |    0.173  |     0.2117 |    1      |    0.001  |   0.001  |      23.8 |          0.1377 |                  3 |
| abilene    | random_link_failure_1   |  20 |     0.0705 |    0.1246 |     0.1543 |    0.9854 |    0.0391 |   0.1    |      28.1 |          0.1638 |                  0 |
| abilene    | random_link_failure_2   |  20 |     0.1179 |    0.1708 |     0.208  |    0.9191 |    0.0089 |   0.0296 |      28.3 |          0.2488 |                  0 |
| abilene    | spike                   |  20 |     0.1808 |    0.2874 |     0.3395 |    1      |    0.0189 |   0.0919 |      37.8 |          0.4796 |                  0 |
| abilene    | mixed_spike_failure     |  20 |     0.1938 |    0.341  |     0.4344 |    0.9998 |    0.0298 |   0.0973 |      37.7 |          0.4809 |                  0 |
| abilene    | capacity_degradation_50 |  20 |     0.1224 |    0.2264 |     0.2268 |    0.9918 |    0.0229 |   0.0901 |      26.4 |          0.3198 |                  0 |
| geant      | normal                  |  20 |     0.121  |    0.1267 |     0.1369 |    0.9912 |    0.0115 |   0.0675 |     550.6 |          0.2901 |                  0 |
| geant      | single_link_failure     |  20 |     0.1808 |    0.1894 |     0.1938 |    0.9938 |    0.0088 |   0.0305 |    1054.2 |          0.3564 |                  0 |
| geant      | two_link_failure        |  20 |     0.1808 |    0.1893 |     0.1922 |    0.9942 |    0.0084 |   0.0213 |     826.6 |          0.3561 |                  0 |
| geant      | three_link_failure      |  20 |     0.1807 |    0.1893 |     0.1913 |    0.9944 |    0.0078 |   0.0187 |     392.2 |          0.3565 |                  0 |
| geant      | random_link_failure_1   |  20 |     0.1211 |    0.1268 |     0.1389 |    0.9906 |    0.0117 |   0.0603 |     814.5 |          0.2901 |                  0 |
| geant      | random_link_failure_2   |  20 |     0.1212 |    0.1269 |     0.1409 |    0.99   |    0.012  |   0.0739 |     450   |          0.2945 |                  0 |
| geant      | spike                   |  20 |     0.363  |    0.38   |     0.4138 |    0.9911 |    0.0117 |   0.0687 |     533.7 |          0.8704 |                  0 |
| geant      | mixed_spike_failure     |  20 |     0.5425 |    0.5681 |     0.5815 |    0.9939 |    0.009  |   0.0307 |     639   |          1.0693 |                  0 |
| geant      | capacity_degradation_50 |  20 |     0.2421 |    0.2535 |     0.2758 |    0.9908 |    0.0157 |   0.0694 |     234   |          0.5802 |                  0 |

## Failure: disconnected-OD detail

| Topology   | Scenario                |   Failed_links | Connected   |   Disconnected_ODs | Explanation                                     |
|:-----------|:------------------------|---------------:|:------------|-------------------:|:------------------------------------------------|
| abilene    | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | three_link_failure      |              3 | partial     |                  3 | some ODs lost all candidate paths under failure |
| abilene    | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| abilene    | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | normal                  |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | single_link_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | two_link_failure        |              2 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | three_link_failure      |              3 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | random_link_failure_1   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | random_link_failure_2   |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | spike                   |              0 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | mixed_spike_failure     |              1 | yes         |                  0 | all ODs keep a surviving path                   |
| geant      | capacity_degradation_50 |              0 | yes         |                  0 | all ODs keep a surviving path                   |

## Proof of learning (trained vs untrained vs random vs fixed)

| policy    |   mean_reward |   mean_PR |   mean_ms |   action_entropy |
|:----------|--------------:|----------:|----------:|-----------------:|
| trained   |       17.8228 |  0.980565 |   66.1272 |      1.39383     |
| untrained |       17.073  |  0.986706 |  129.168  |      0.307941    |
| random    |       15.222  |  0.971916 |   99.7348 |      1.94453     |
| keep      |      -10.0477 |  0.687997 |    0.5    |     -1.00009e-12 |
| k800      |       17.6145 |  0.9933   |  177.999  |     -1.00009e-12 |

## Learning curve
TD loss 2.096->0.643; reward 15.16->18.03; td_updates=20620, ce_updates=0